//
//  Protocols.swift
//  Convertify
//
//  Created by apple on 8/6/20.
//  Copyright © 2020 apple001. All rights reserved.
//

import UIKit

var topPadding: CGFloat?

protocol HomeControllerDelegate {
    func handleMenuToggle(forIndex index: Int?)
}


