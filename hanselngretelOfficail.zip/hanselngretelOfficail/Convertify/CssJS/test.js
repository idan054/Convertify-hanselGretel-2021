
alert("JavaScript is injected!");
